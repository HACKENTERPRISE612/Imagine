// Wrap every letter in a span
var textWrapper = document.querySelector('.ml3');
textWrapper.innerHTML = textWrapper.textContent.replace(/\S/g, "<span class='letter'>$&</span>");

anime.timeline()
  .add({
    targets: '.ml3 .letter',
    opacity: [0,1],
    easing: "easeInQuad",
    delay: (el, i) => 125 * (i+1)
  });